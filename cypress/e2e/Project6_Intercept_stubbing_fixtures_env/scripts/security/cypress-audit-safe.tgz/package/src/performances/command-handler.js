const defaultThresholds = {
  performance: 100,
  accessibility: 100,
  "best-practices": 100,
  seo: 100,
  pwa: 100,
};

const VALID_BROWSERS = {
  Chrome: true,
  Chromium: true,
  Canary: true,
};

const lighthouseCommandHandler = (thresholds, opts, config) => {
  if (!VALID_BROWSERS[Cypress.browser.displayName]) {
    throw new Error(`${Cypress.browser.displayName} cannot run this audit; use Chrome or Chromium`);
  }

  return cy.url().then((url) => {
    const configThresholds = Cypress.config("lighthouse");

    if (!thresholds && !configThresholds) {
      cy.log(
        "cypress-audit",
        "It looks like you have not set thresholds yet. The test will be based on the 100 score for every metrics. Refer to https://github.com/mfrachet/cypress-audit to have more information and set thresholds by yourself :)."
      );
    }

    cy.log("-------- cy.lighthouse --------");
    return cy
      .task("lighthouse", {
        url,
        thresholds: thresholds || configThresholds || defaultThresholds,
        opts,
        config,
      })
      .then(({ errors, results }) => {
        results.forEach((res) => {
          cy.log(res);
        });
        cy.log("-----------------------------");

        return cy.wrap(errors);
      })
      .then((errors) => {
        if (errors.length > 0) {
          const formatedErrors = `\n\n${errors.join("\n")}`;

          const label =
            errors.length === 1
              ? `cy.lighthouse - A threshold has been crossed.${formatedErrors}`
              : `cy.lighthouse - Some thresholds have been crossed.${formatedErrors}`;
          throw new Error(label);
        }
      });
  });
};

module.exports = lighthouseCommandHandler;
